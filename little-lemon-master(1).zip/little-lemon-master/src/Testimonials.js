import React from 'react';

function Testimonials() {
  return (
    <section id="testimonials">
      <h2>Testimonials</h2>
      <div className='customers'>
        <div className='customer-left'>
          <img src="/path/to/customer1.jpg" alt="Customer 1" />
          <div className='customer-text'>
            <p>"The food at Little Lemon is absolutely fantastic! The flavors are so rich and authentic. Highly recommended!"</p>
            <p><strong>John Doe</strong>, Customer</p>
          </div>
        </div>
        <div className='customer-right'>
          <img src="/path/to/customer2.jpg" alt="Customer 2" />
          <div className='customer-text'>
            <p>"Great atmosphere and excellent service. I always enjoy dining here with my family!"</p>
            <p><strong>Jane Smith</strong>, Regular Customer</p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Testimonials;
