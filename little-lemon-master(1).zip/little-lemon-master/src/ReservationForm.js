import React, { useState } from 'react';

const ReservationForm = ({ addReservation, availableTimes }) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [numberOfGuests, setNumberOfGuests] = useState(1);
  const [reservationDate, setReservationDate] = useState('');
  const [reservationTime, setReservationTime] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newReservation = {
      fullName,
      email,
      phone,
      numberOfGuests,
      reservationDate,
      reservationTime,
    };
    addReservation(newReservation);
  };

  return (
    <section id="reservation-form">
      <form className="reservation-form" onSubmit={handleSubmit}>
        <h2>Make a Reservation</h2>
        <div className="form-group">
          <label htmlFor="fullName">Full Name</label>
          <input
            type="text"
            id="fullName"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone</label>
          <input
            type="tel"
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="numberOfGuests">Number of Guests</label>
          <input
            type="number"
            id="numberOfGuests"
            value={numberOfGuests}
            onChange={(e) => setNumberOfGuests(e.target.value)}
            required
            min="1"
          />
        </div>
        <div className="form-group">
          <label htmlFor="reservationDate">Date</label>
          <input
            type="date"
            id="reservationDate"
            value={reservationDate}
            onChange={(e) => setReservationDate(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="reservationTime">Time</label>
          <select
            id="reservationTime"
            value={reservationTime}
            onChange={(e) => setReservationTime(e.target.value)}
          >
            <option value="">Select a time</option>
            {availableTimes.map((time) => (
              <option key={time} value={time}>{time}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="reservation-button">Reserve</button>
      </form>
    </section>
  );
};

export default ReservationForm;
