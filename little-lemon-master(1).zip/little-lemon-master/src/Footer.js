import React from 'react';

function Footer() {
  return (
    <footer>
      <div className="footer-content">
        <div className="footer-section about">
          <h2>About Us</h2>
          <p>We are passionate about delivering authentic Italian cuisine with fresh ingredients and exceptional flavors.</p>
        </div>
        <div className="footer-section contact">
          <h2>Contact Us</h2>
          <p><i className="fa fa-phone"></i> Phone: +1 234 567 890</p>
          <p><i className="fa fa-envelope"></i> Email: info@littlelemon.com</p>
        </div>
        <div className="footer-section social">
          <h2>Follow Us</h2>
          <p><i className="fa fa-facebook"></i> <a href="https://facebook.com/" target="_blank" rel="noopener noreferrer">Facebook</a></p>
          <p><i className="fa fa-twitter"></i> <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer">Twitter</a></p>
          <p><i className="fa fa-instagram"></i> <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer">Instagram</a></p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; 2024 Little Lemon. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
