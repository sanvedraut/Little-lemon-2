import React from 'react';

const Reservations = ({ reservations }) => (
  <section id="reservations">
    <h2>Reservations</h2>
    <ul>
      {reservations.map((reservation, index) => (
        <li key={index}>
          <strong>{reservation.fullName}</strong> - {reservation.reservationDate} at {reservation.reservationTime} for {reservation.numberOfGuests} guests
        </li>
      ))}
    </ul>
  </section>
);

export default Reservations;
