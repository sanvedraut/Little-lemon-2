import React, { useState, useEffect, useReducer } from 'react';
import Navbar from './Navbar';
import Hero from './Hero';
import Highlights from './Highlights';
import Testimonials from './Testimonials';
import About from './About';
import Footer from './Footer';
import ReservationForm from './ReservationForm';
import Reservations from './Reservations';

// Reducer for managing available times
const timesReducer = (state, action) => {
  switch (action.type) {
    case 'SET_TIMES':
      return action.payload;
    default:
      return state;
  }
};

const Main = () => {
  const [reservations, setReservations] = useState([]);
  const [availableTimes, dispatch] = useReducer(timesReducer, []);

  // Generate time slots
  const generateTimeSlots = (start, end, interval) => {
    const times = [];
    let current = new Date();
    current.setHours(start, 0, 0, 0); // set the start time
  
    while (current.getHours() < end || (current.getHours() === end && current.getMinutes() === 0)) {
      const hours = current.getHours().toString().padStart(2, '0');
      const minutes = current.getMinutes().toString().padStart(2, '0');
      times.push(`${hours}:${minutes}`);
      current.setMinutes(current.getMinutes() + interval);
    }
  
    return times;
  };
  
  

  const fetchReservations = async () => {
    try {
      const response = await fetch('http://localhost:5000/reservations');
      const data = await response.json();
      setReservations(data);
      dispatch({ type: 'SET_TIMES', payload: generateTimeSlots(13, 22, 15) });
    } catch (error) {
      console.error('Error fetching reservations:', error);
    }
  };

  // Fetch initial data
  useEffect(() => {
    fetchReservations();
  }, []);

  const addReservation = async (newReservation) => {
    try {
      const response = await fetch('http://localhost:8081/reservations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newReservation),
      });

      if (response.ok) {
        const savedReservation = await response.json();
        const updatedReservations = [...reservations, savedReservation];
        setReservations(updatedReservations);
        dispatch({ type: 'SET_TIMES', payload: generateTimeSlots(13, 22, 15) });
      } else {
        console.error('Failed to save reservation');
      }
    } catch (error) {
      console.error('Error saving reservation:', error);
    }
  };

  return (
    <div>
      <Navbar />
      <Hero />
      <Highlights />
      <Testimonials />
      <About />
      <ReservationForm addReservation={addReservation} availableTimes={availableTimes} />
      <Reservations reservations={reservations} />
      <Footer />
    </div>
  );
};

export default Main;
