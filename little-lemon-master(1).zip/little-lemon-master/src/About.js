import React from 'react';

function About() {
  return (
    <article id="about">
      <h2>About Us</h2>
      <div>
        <p>This is the about section. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed nibh id risus accumsan rutrum.</p>
        <p>Nulla facilisi. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
      </div>
      <div>
        <h3>Our Mission</h3>
        <p>Our mission is to provide delicious Italian cuisine with a focus on fresh ingredients and authentic flavors.</p>
        <h3>Our Vision</h3>
        <p>To become the preferred Italian restaurant in our community by delivering exceptional dining experiences.</p>
      </div>
    </article>
  );
}

export default About;
