import React from 'react';

const Navbar = () => {
  const handleScroll = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="navbar">
      <ul>
        <li><a href="#hero" onClick={() => handleScroll('hero')}>Home</a></li>
        <li><a href="#highlights" onClick={() => handleScroll('highlights')}>Highlights</a></li>
        <li><a href="#testimonials" onClick={() => handleScroll('testimonials')}>Testimonials</a></li>
        <li><a href="#about" onClick={() => handleScroll('about')}>About</a></li>
        <li><a href="#reservation-form" onClick={() => handleScroll('reservation-form')}>Reservations</a></li>
      </ul>
    </nav>
  );
};

export default Navbar;
