import React from 'react';

function Highlights() {
  return (
    <article id="highlights">
      <h1>Specials</h1>
      <div className="card">
        <img src="/path/to/italian-food-1.jpg" alt="Italian Food 1" />
        <div className="description">
          <p>Description of Italian Food 1</p>
        </div>
      </div>
      <div className="card">
        <img src="/path/to/italian-food-2.jpg" alt="Italian Food 2" />
        <div className="description">
          <p>Description of Italian Food 2</p>
        </div>
      </div>
      <div className="card">
        <img src="/path/to/italian-food-3.jpg" alt="Italian Food 3" />
        <div className="description">
          <p>Description of Italian Food 3</p>
        </div>
      </div>
    </article>
  );
}

export default Highlights;
