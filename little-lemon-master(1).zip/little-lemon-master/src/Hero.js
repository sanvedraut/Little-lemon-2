import React from 'react';

const Hero = () => (
  <section id="hero">
    <div className="hero-left">
      <div className="herePic"></div>
      <button>Book Now</button>
    </div>
    <div className="hero-right">
      <h1>Welcome to Our Restaurant</h1>
      <p>Experience the best dining experience with us.</p>
    </div>
  </section>
);

export default Hero;
